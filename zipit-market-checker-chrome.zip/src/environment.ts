export const environment = {
  zipit_base_api_url: "https://staging.cms.zipit.gg/api",
  zipit_base_api_url_live: "https://cms.zipit.gg/api",
  zipit_login:"https://cms.zipit.gg/auth"
};
