// popup.tsx
import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
import "./popup.css"; // Importing CSS file

const Popup: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean | null>(null);
  const [steamLoginSecure, setSteamLoginSecure] = useState<string | null>(null);

  async function fetchSteamToken() {
    try {
      const resp = await fetch("https://steamcommunity.com", {
        credentials: "include",
        headers: {
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9;q=0.8,application/signed-exchange;v=b3;q=0.7",
        },
      });

      const body = await resp.text();
      const match = /data-loyalty_webapi_token="&quot;([a-zA-Z0-9_.-]+)&quot;"/.exec(body);

      if (!match || match.length < 2) {
        setIsLoggedIn(false);
        setSteamLoginSecure(null);
        throw new Error("Failed to parse web API token.");
      }

      const token = match[1];
      setSteamLoginSecure(token);
      const steamID = extractSteamID(body);
      if (steamID) {
        // If Steam ID is found, the user is logged in.
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
      }

      //   if (steamID) {
      //     throw new Error("user is not logged into the expected steam account");
      //   }

      console.log(token, "token");

      // Store the token in Chrome storage
      chrome.storage.local.set({ steamToken: token }, () => {
        console.log("Steam API token saved.");
      });
    } catch (error) {
      console.error("Error fetching Steam token:", error);
    }
  }

  useEffect(() => {
    const checkExtension = (extensionId: string): void => {
      if (chrome.runtime) {
        chrome.runtime.sendMessage(extensionId, { action: "check" }, () => {
          if (chrome.runtime.lastError) {
            console.log("Extension not installed");
          } else {
            console.log("Extension installed");
          }
        });
      } else {
        console.log("Chrome runtime not available");
      }
    };

    // Replace with your extension's ID
    checkExtension("dkgeeggphoecgekcidocioljiajlipkj");
  }, []);

  function extractSteamID(body: string): string | null {
    const steamIDMatch = /g_steamID = "(\d+?)"/.exec(body);
    if (!steamIDMatch || steamIDMatch.length === 0) {
      return null;
    }

    return steamIDMatch[1];
  }

  useEffect(() => {
    fetchSteamToken();
    // chrome.storage.local.get("steamToken", (data) => {
    //   console.log(data, "data");

    //   if (data.steamToken) {
    //     setSteamLoginSecure(data.steamToken);
    //     setIsLoggedIn(false);
    //   } else {
    //     setSteamLoginSecure(null);
    //   }
    // });
  }, []);

  const handleLogin = () => {
    chrome.tabs.create({ url: "https://staging.cms.zipit.gg/auth" });
  };

  return (
    <div className='popup-container'>
      <h1>Steam Login Checker</h1>
      {isLoggedIn === null ? (
        <p>Checking login status...</p>
      ) : steamLoginSecure ? (
        <p>welcome to zipit </p>
      ) : (
        <button onClick={handleLogin}>Login via Steam</button>
      )}
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root") as HTMLElement);
root.render(<Popup />);
