window.addEventListener("message", (event: MessageEvent) => {
  // Allowed origins
  const allowedOrigins = ["https://zipit.gg", "https://staging.zipit.gg"];

  // Check if event.origin is in the allowed list
  if (!allowedOrigins.includes(event.origin)) return;

  // Ensure event.data has the expected structure
  if (typeof event.data !== "object" || event.data === null) return;

  // Send the message to the background script
  browser.runtime.sendMessage(event.data).catch((error) => {
    console.error("Error sending message to background script:", error);
  });
});
